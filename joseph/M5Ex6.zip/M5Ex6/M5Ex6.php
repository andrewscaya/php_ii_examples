<?php
require_once('class.Product.php');
require_once('Product.php');

$storeProduct = new MyEcommerce\Product(1954);
$numericProduct = new FastMath\Product(234,18);