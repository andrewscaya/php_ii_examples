<?php
namespace FastMath;
class Product {
	public function __construct($x,$y) {
		echo 'The product of these numbers is ' . $x * $y . PHP_EOL;
	}
}